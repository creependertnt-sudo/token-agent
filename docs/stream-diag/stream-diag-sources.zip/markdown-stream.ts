/**
 * 流式 Markdown 安全门控：
 * 半截符号先留在 pending，成对/闭合后再并入 display。
 * 「等完整再显示」，而不是删掉。
 */

/** 忽略列表 bullet（行首 * + 空白），避免 `* item` 永远不成对 */
function starsForPairCheck(text: string): string {
  return text.replace(/(^|\n)([ \t]*)\*(?=[ \t])/g, "$1$2");
}

/**
 * 当前文本是否可安全展示（无半截强调 / 代码块 / 链接）。
 */
export function isMarkdownSafe(text: string): boolean {
  if (!text) return true;

  // 1. * 成对（列表 bullet 不计入）
  if ((starsForPairCheck(text).match(/\*/g) || []).length % 2 !== 0) {
    return false;
  }

  // 2. ``` 成对
  if ((text.match(/```/g) || []).length % 2 !== 0) {
    return false;
  }

  // 3. 链接未闭合：[text](url
  if (/\[[^\]]*\]\([^)]*$/.test(text)) return false;

  // 3b. 半截 [text
  if (/\[[^\]]*$/.test(text)) return false;

  return true;
}

/**
 * 追加 chunk：仅当 pending 整体安全时才并入 display。
 */
export function appendSafeMarkdownStream(
  displayText: string,
  pendingText: string,
  chunk: string,
): { displayText: string; pendingText: string } {
  const pending = `${pendingText}${chunk}`;
  if (isMarkdownSafe(pending)) {
    return {
      displayText: `${displayText}${pending}`,
      pendingText: "",
    };
  }
  return { displayText, pendingText: pending };
}

/**
 * 将已有全文拆成可展示前缀 + 半截后缀（兼容旧调用）。
 */
export function splitStreamingMarkdown(content: string): {
  markdown: string;
  pending: string;
} {
  if (!content) return { markdown: "", pending: "" };
  if (isMarkdownSafe(content)) {
    return { markdown: content, pending: "" };
  }

  // 从末尾缩短，找到最长安全前缀
  for (let i = content.length - 1; i >= 0; i -= 1) {
    const head = content.slice(0, i);
    if (isMarkdownSafe(head)) {
      return { markdown: head, pending: content.slice(i) };
    }
  }
  return { markdown: "", pending: content };
}
